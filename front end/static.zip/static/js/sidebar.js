// static/js/sidebar.js
document.addEventListener('DOMContentLoaded', function() {
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.getElementById('main-content');
    const toggleBtn = document.getElementById('sidebar-toggle');

    // Vérifier l'état du localStorage
    const isSidebarCollapsed = localStorage.getItem('sidebarCollapsed') === 'true';

    if (isSidebarCollapsed) {
        collapseSidebar();
    }

    // Toggle sidebar
    toggleBtn.addEventListener('click', function() {
        if (sidebar.classList.contains('collapsed')) {
            expandSidebar();
        } else {
            collapseSidebar();
        }
    });

    function collapseSidebar() {
        sidebar.classList.add('collapsed');
        mainContent.classList.add('expanded');
        toggleBtn.innerHTML = '<i class="bi bi-list"></i>';
        localStorage.setItem('sidebarCollapsed', 'true');
    }

    function expandSidebar() {
        sidebar.classList.remove('collapsed');
        mainContent.classList.remove('expanded');
        toggleBtn.innerHTML = '<i class="bi bi-x"></i>';
        localStorage.setItem('sidebarCollapsed', 'false');
    }

    // Gestion responsive
    function handleResize() {
        if (window.innerWidth < 992) {
            collapseSidebar();
        } else {
            expandSidebar();
        }
    }

    window.addEventListener('resize', handleResize);
    handleResize(); // Initial check
});